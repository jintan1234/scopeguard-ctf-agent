This archive contains a nested recovery task.
